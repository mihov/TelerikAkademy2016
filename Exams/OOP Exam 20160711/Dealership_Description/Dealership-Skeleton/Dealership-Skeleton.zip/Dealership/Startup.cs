﻿using Dealership.Engine;
using Dealership.Models;

namespace Dealership
{
    public class Startup
    {
        public static void Main()
        {
            DealershipEngine.Instance.Start();

          
        }
    }
}
