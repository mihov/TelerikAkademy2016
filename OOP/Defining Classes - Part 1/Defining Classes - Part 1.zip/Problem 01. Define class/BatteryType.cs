﻿namespace MobileDevice
{
    internal enum BatteryType
    {
        LiIon,
        LiPol,
        NiMH,
        NiCd
    }

}
