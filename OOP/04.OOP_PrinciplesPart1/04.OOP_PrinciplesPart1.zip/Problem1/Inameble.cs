﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem1
{
    public interface Inameble
    {
        string Name { get; set; }
    }
}