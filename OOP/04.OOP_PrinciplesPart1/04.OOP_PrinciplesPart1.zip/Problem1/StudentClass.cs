﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem1
{
    public class StudentClass : HasName
    {
        private List<Teacher> teachersSet;
        private List<Student> studentSet;
        private List<Discipline> disciplineSet;

        public StudentClass(String name) : base(name)
        {
            teachersSet = new List<Teacher>();
            studentSet = new List<Student>();
            disciplineSet = new List<Discipline>();
        }


        public void AddStudent(Student value)
        {
            this.studentSet.Add(value);
        }

        public bool RemoveStudent(Student value)
        {
            return this.studentSet.Remove(value);
        }

        public String PrintStudent()
        {
            StringBuilder result = new StringBuilder();
            foreach (var student in this.studentSet)
            {
                result.AppendLine(student.Name);
            }
            return result.ToString();
        }

        public void AddDiscipline(Discipline value)
        {
            this.disciplineSet.Add(value);
        }

        public bool RemoveDiscipline(Discipline value)
        {
            return this.disciplineSet.Remove(value);
        }

        public String PrintDiscipline()
        {
            StringBuilder result = new StringBuilder();
            foreach (var discipline in this.disciplineSet)
            {
                result.AppendLine(discipline.Name);
            }
            return result.ToString();
        }

        public void AddTeacher(Teacher value)
        {
            this.teachersSet.Add(value);
        }

        public bool RemoveTeacher(Teacher value)
        {
            return this.teachersSet.Remove(value);
        }

        public String PrintTeachers()
        {
            StringBuilder result = new StringBuilder();
            foreach (var teachers in this.teachersSet)
            {
                result.AppendLine(teachers.Name);
            }
            return result.ToString();
        }
    }
}