﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem1
{
    public class Discipline : HasName
    {
        private String name;

        public Discipline(String name):base(name)
        {
           
        }

        public int Lectures { get; set; }

        public int Exercises { get; set; }

        


    }
}