﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem1
{
    class StartUp
    {
        static void Main(string[] args)
        {
            School NBU = new School("NBU");
            Console.WriteLine(NBU);
            Console.WriteLine();

            Discipline history = new Discipline("History");
            history.Lectures = 12;
            history.Exercises = 10;

            Discipline iconomy = new Discipline("Iconomy");
            history.Lectures = 20;
            history.Exercises = 25;

            Discipline politology = new Discipline("Politology");
            history.Lectures = 30;
            history.Exercises = 40;

            Discipline teniss = new Discipline("Teniss");
            history.Lectures = 50;
            history.Exercises = 60;

            Student ivanIvanov = new Student("Ivan Ivanov");
            ivanIvanov.UCNumber = "11223344";
            ivanIvanov.Comment = "Play futbol";

            Student vasilStoianov = new Student("Vasil Stoianov");
            ivanIvanov.UCNumber = "55667788";
            ivanIvanov.Comment = "Play piano";

            Teacher georgiIvanov = new Teacher("Georgi Ivanov");
            georgiIvanov.AddDiscipline(iconomy);
            georgiIvanov.AddDiscipline(politology);
            georgiIvanov.AddDiscipline(history);
            georgiIvanov.Comment = "Most wanted!";

            Console.WriteLine(georgiIvanov);
            Console.WriteLine(georgiIvanov.PrintDisciplines());

            Teacher kirilSpasov = new Teacher("Kiril Spasov");
            kirilSpasov.AddDiscipline(teniss);

            Console.WriteLine();
            Console.WriteLine(kirilSpasov);
            Console.WriteLine(kirilSpasov.PrintDisciplines());

            StudentClass class12A = new StudentClass("12 A");
            class12A.AddTeacher(kirilSpasov);
            class12A.AddTeacher(georgiIvanov);

            NBU.AddClass(class12A);



        }
    }
}
