﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem1
{
    public interface Icommentable
    {
        String Comment { get; set; }
    }
}