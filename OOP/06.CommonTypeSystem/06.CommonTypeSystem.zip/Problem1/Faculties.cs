﻿namespace Problem1
{
    public enum Faculties
    {
        Sports,
        Low,
        SoftDev,
        Medicine
    }
}
