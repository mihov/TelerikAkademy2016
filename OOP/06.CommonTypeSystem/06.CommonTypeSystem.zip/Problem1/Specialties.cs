﻿namespace Problem1
{
    public enum Specialties
    {
        WebDesign,
        InternationalLow,
        GP,
        Running
    }
}
