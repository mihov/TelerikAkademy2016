﻿namespace Problem1
{
    public enum Universities
    {
        MGU,
        NBU,
        SoftUni,
        American
    }
}
