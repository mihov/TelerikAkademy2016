﻿namespace Problem1
{
    class StartUp
    {
        static void Main(string[] args)
        {
            StudentClassTest.TestOverriddenMethods();

            PersonTest.PersonToString();
        }
    }
}
