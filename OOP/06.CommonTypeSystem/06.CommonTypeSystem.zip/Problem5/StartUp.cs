﻿namespace Problem5
{
    class StartUp
    {
        static void Main()
        {
            TestingBitArray64.TestImplementations();
        }
    }
}
